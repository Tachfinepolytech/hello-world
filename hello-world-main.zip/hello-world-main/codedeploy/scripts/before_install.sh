#!/bin/bash

yum install -y docker

systemctl start docker