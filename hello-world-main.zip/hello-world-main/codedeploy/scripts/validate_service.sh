#!/bin/bash

docker ps | grep hello-world