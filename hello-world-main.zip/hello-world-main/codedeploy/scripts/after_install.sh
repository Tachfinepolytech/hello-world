#!/bin/bash

# Validating whether docker is installed or not
systemctl is-active --quiet docker