#!/bin/bash

docker rm -f hello-world || true